// internal/service/user_service.go
package service

import (
	"context"
	"errors"
	"time"

	"github.com/P1punGorbach/backend/internal/models"
	"github.com/P1punGorbach/backend/internal/repository"
	"github.com/golang-jwt/jwt/v5"
	"golang.org/x/crypto/bcrypt"
)

var (
	ErrUserAlreadyExists  = errors.New("пользователь с такой почтой уже существует")
	ErrInvalidCredentials = errors.New("неверная почта или пароль")
)

type UserService struct {
	repo UserRepository // твой репозиторий
}

type UserRepository interface {
	Create(ctx context.Context, user *models.User) error
	GetByEmail(ctx context.Context, email string) (*models.User, error)
	GetByID(ctx context.Context, id int) (*models.User, *models.UserProfile, error)
	// другие методы, которые тебе нужны
}

func NewUserService(r *repository.UserRepo) *UserService {
	return &UserService{repo: r}
}

// RegisterInput — структура входных данных
type RegisterInput struct {
	Email    string `json:"email" binding:"required,email"`
	Password string `json:"password" binding:"required,min=6"`
}

// Register создаёт пользователя, хеширует пароль и сохраняет в БД
func (s *UserService) Register(ctx context.Context, in RegisterInput) (*models.User, error) {
	// Проверяем, существует ли пользователь с таким email
	existingUser, err := s.repo.GetByEmail(ctx, in.Email)
	if err != nil && !errors.Is(err, repository.ErrNotFound) {
		return nil, err
	}
	if existingUser != nil {
		return nil, ErrUserAlreadyExists
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(in.Password), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	user := &models.User{
		Email:        in.Email,
		PasswordHash: string(hash),
	}

	if err := s.repo.Create(ctx, user); err != nil {
		return nil, err
	}

	return user, nil
}

type LoginInput struct {
	Email    string `json:"email"    binding:"required,email"`
	Password string `json:"password" binding:"required"`
}

func (s *UserService) Login(ctx context.Context, in LoginInput) (*models.User, string, error) {
	// Ищем пользователя по email
	user, err := s.repo.GetByEmail(ctx, in.Email)
	if err != nil {
		if errors.Is(err, repository.ErrNotFound) {
			return nil, "", ErrInvalidCredentials
		}
		return nil, "", err
	}

	// Сравниваем хеш пароля
	if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(in.Password)); err != nil {
		return nil, "", ErrInvalidCredentials
	}
	token, err := generateToken(user.ID)
	if err != nil {
		return nil, "", err
	}

	return user, token, nil
}
func (s *UserService) GetUserInfo(ctx context.Context, token string) (*models.User, *models.UserProfile, error) {

	userID, err := parseToken(token)
	if err != nil {
		return nil, nil, err
	}
	user, profile, err := s.repo.GetByID(ctx, userID)
	if err != nil {
		return nil, nil, err
	}

	return user, profile, nil
}
func parseToken(token string) (int, error) {
	// Пример реализации с использованием библиотеки jwt-go
	type Claims struct {
		UserID int `json:"user_id"`
		jwt.RegisteredClaims
	}

	// Здесь нужно использовать секретный ключ, который ты использовал для подписания токена
	secretKey := []byte("your_secret_key")

	tokenObj, err := jwt.ParseWithClaims(token, &Claims{}, func(t *jwt.Token) (interface{}, error) {
		return secretKey, nil
	})
	if err != nil {
		return 0, err
	}

	claims, ok := tokenObj.Claims.(*Claims)
	if !ok || !tokenObj.Valid {
		return 0, errors.New("invalid token")
	}

	return claims.UserID, nil
}
func generateToken(userID int) (string, error) {
	// Пример реализации с использованием библиотеки jwt-go
	type Claims struct {
		UserID int `json:"user_id"`
		jwt.RegisteredClaims
	}

	secretKey := []byte("your_secret_key")
	expirationTime := time.Now().Add(24 * time.Hour)

	claims := &Claims{
		UserID: userID,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(expirationTime),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString(secretKey)
}
