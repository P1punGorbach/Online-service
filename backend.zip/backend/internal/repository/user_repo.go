// internal/repository/user_repo.go
package repository

import (
	"context"
	"database/sql"
	"errors"
	"time"

	"github.com/P1punGorbach/backend/internal/models"
)

var ErrNotFound = errors.New("не найдено")

type UserRepo struct {
	db *sql.DB
}

func NewUserRepo(db *sql.DB) *UserRepo {
	return &UserRepo{db: db}
}

// Create сохраняет нового пользователя в БД
func (r *UserRepo) Create(ctx context.Context, user *models.User) error {
	user.CreatedAt = time.Now()

	_, err := r.db.ExecContext(ctx, `
        INSERT INTO users (email, password_hash, created_at)
        VALUES ($1, $2, $3)
    `, user.Email, user.PasswordHash, user.CreatedAt)
	return err
}
func (r *UserRepo) GetByEmail(ctx context.Context, email string) (*models.User, error) {
	var user models.User
	err := r.db.QueryRowContext(ctx, `
        SELECT id, email, password_hash, created_at
        FROM users WHERE email = $1
    `, email).Scan(&user.ID, &user.Email, &user.PasswordHash, &user.CreatedAt)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, ErrNotFound
		}
		return nil, err
	}
	return &user, nil
}
func (r *UserRepo) GetByID(ctx context.Context, id int) (*models.User, *models.UserProfile, error) {
	var user models.User
	var profile models.UserProfile

	err := r.db.QueryRowContext(ctx, `
SELECT
    u.id,
    u.email,
    u.password_hash,
    u.is_active,
    u.created_at,
    u.updated_at,
    u.is_admin,
    up.name,
    up.height_cm,
    up.weight_kg,
    p.name -- имя позиции
FROM public.users u
INNER JOIN public.user_profiles up ON u.id = up.user_id
INNER JOIN public.positions p ON up.position_id = p.id
WHERE u.id = $1
    `, id).Scan(&user.ID, &user.Email, &user.PasswordHash, &user.IsActive, &user.CreatedAt, &user.UpdatedAt, &user.IsAdmin, &profile.Name, &profile.HeightCm, &profile.WeightKg, &profile.PositionName)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, nil, ErrNotFound
		}
		return nil, nil, err
	}
	return &user, &profile, nil
}
